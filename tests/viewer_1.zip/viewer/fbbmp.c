/*
 * fbbmp.c : bmp drawing on frame buffer example
 *
 * Copyright(C) 2002 holelee
 *
 */

#include <stdio.h>
#include <stdlib.h> /* for exit */
#include <unistd.h> /* for open/close .. */
#include <fcntl.h>  /* for O_RDONLY */
#include <sys/ioctl.h> /* for ioctl */
#include <sys/mman.h> /* for mmap */
#include <linux/fb.h>  /* for fb_var_screeninfo, FBIOGET_VSCREENINFO */
#include <string.h>

#include "bmplib.h"

#define MIN(x, y) ((x) > (y) ? (y) : (x))

//#define FBDEVFILE "/dev/fb0"
#define FBDEVFILE "/dev/oofb"
//#define FBDEVFILE "/dev/fb/0"


#define START_X 0  //start x,y point  default (0.0)
#define START_Y 0

#define debug 0


typedef unsigned char ubyte;

unsigned char* area_p;
struct fb_var_screeninfo fbvar;
bmphandle_t bh;
unsigned short *pfbmap;
struct bgrpixel pixel;

int split (int x, int y);
void road_bmp (char* fname);
void show_area( char* area_p, int cmd , int x, int y);


static unsigned short makepixel(struct fb_var_screeninfo *pfbvar, ubyte r, ubyte g, ubyte b)
{
	unsigned short rnew, gnew, bnew;

	rnew = r >> (8-pfbvar->red.length);
	gnew = g >> (8-pfbvar->green.length);
	bnew = b >> (8-pfbvar->blue.length);

	return (unsigned short) ((rnew << pfbvar->red.offset)
			| (gnew << pfbvar->green.offset)
			| (bnew << pfbvar->blue.offset));
}







int main(int argc, char *argv[])
{
	int fbfd;
	//unsigned short *pfbmap;
//	struct fb_var_screeninfo fbvar;
	int i, j;
//	struct bgrpixel pixel;
	//bmphandle_t bh;

	int x,y;
	int cmd ; //screen selection command  [1~4] 
	
	if(argc != 3)
	{
		fprintf(stderr, "Usage:%s bmpfile cmd[1~4]\n", argv[0]);
		exit(1);
	}



	cmd = atoi(argv[2]);
	printf(" test cmd  = %d \n", cmd );	
	if( cmd < 1 || cmd > 4)
	{
		fprintf(stderr, "cmd is 1~4 \n");
		exit(1);
	}


/*
	bh = bmp_open(argv[1]);
	if(bh == NULL)
	{
		fprintf(stderr, "Cannot open bmp file(%s)\n", argv[1]);
		fprintf(stderr, "File may be not bmp. Or file may be not supported by this program\n");
		exit(0);
	}
*/
	road_bmp (argv[1]);


	fbfd = open(FBDEVFILE, O_RDWR);

	if(fbfd < 0)
	{
		perror("fbdev open");
		exit(1);
	}

	if(ioctl(fbfd, FBIOGET_VSCREENINFO, &fbvar) < 0)
	{
		perror("fbdev ioctl");
		exit(1);
	}

	if(fbvar.bits_per_pixel != 16)
	{
		fprintf(stderr, "bpp is not 16\n");
		exit(1);
	}

	pfbmap = (unsigned short *)
		mmap(0, fbvar.xres*fbvar.yres*16/8,
			PROT_READ|PROT_WRITE, MAP_SHARED, fbfd, 0);

	if((unsigned)pfbmap == (unsigned)-1)
	{
		perror("fbdev mmap");
		exit(1);
	}
	
	printf("\n input x :  ");
	scanf("%d",&x);

	printf("\n  input y :  ");
	scanf("%d",&y);

	//memset(pfbmap, 0, fbvar.xres*fbvar.yres*16/8);

	split(x,y);
	
	show_area( area_p,cmd,x,y);
/*
	for(i=0; i<50 ; i++)
	{
		x++;
		y++;
	
		show_area( area_p,cmd,x,y);
	}
*/
/*
	// main loop 
	for(i = 0; i < MIN(bmp_height(bh), fbvar.yres); i++)
	{
		for(j = 0; j < MIN(bmp_width(bh), fbvar.xres); j++)
		{
			pixel = bmp_getpixel(bh, j, i);
			*(pfbmap+i*fbvar.xres+j) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
		}
	}
*/
/*
	switch(cmd)
	{
		case 1 : screen_x = 0 ;
			 screen_y = 0 ;
			 break;

		case 2 : screen_x = 320 ;
			 screen_y = 0 ;
			 break;

		case 3 : screen_x = 0 ;
			 screen_y = 240 ;
			 break;

		case 4 : screen_x = 320 ;
			 screen_y = 240 ;
			 break;
	}//end switch

*/
/*
	for(i = 0; i < MIN(bmp_height(bh), fbvar.yres); i++)
	{
		for(j = 0; j < MIN(bmp_width(bh), fbvar.xres); j++)
		{
			pixel = bmp_getpixel(bh, j+screen_x, i+screen_y);
			*(pfbmap+(i+ START_Y)*fbvar.xres + (j+START_X) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
		}
	}



*/
	/* clean up */
	bmp_close(bh);
	
//	bmp_close(bh_a);
//	free(area_a);
	
	munmap(pfbmap, fbvar.xres*fbvar.yres*16/8);
	close(fbfd);
	exit(0);
	return 0;
}


void road_bmp (char* fname)
{
 
#if debug
	printf(" road_bmp call \n");
#endif

	bh = bmp_open(fname);
	if(bh == NULL)
	{
		fprintf(stderr, "Cannot open bmp file(%s)\n", fname);
		fprintf(stderr, "File may be not bmp. Or file may be not supported by this program\n");
		exit(0);
	}

	printf("data is %x \n",bh->data);

}


int split (int x, int y)
{

	
#if debug
	printf(" split call \n");
#endif
	
	int i=0;
	int offset = 0 ;
	int offset_area = 0 ;

	int bpp = (bh->bpp / 8);
	size_t line = 320*1*bpp ;// 

	area_p = (char*) malloc(320*240*bpp);
	memset(area_p, 0xfff , (320*240*2));	
	
	/*
	offset = y*bh->width + x;

	for(i=0 ; i<240 ; i++ )
	{

			memcpy( area_p +offset_area , bh->data + offset , line);
			//memcpy( area_p +offset , (void*)bh->data  , line);
			
			offset += (bh->width * bpp);

			offset_area += line ; 

	}//end for 
	*/
	return 0;

}




void show_area( char* area_p, int cmd , int x, int y)
{


#if debug
	printf(" show area call \n");
#endif
   
	int count =0 ;
	int i, j;
	bmphandle_t bh_a;
	struct bgrpixel pixel;

	memset(pfbmap, 0, fbvar.xres*fbvar.yres*16/8);

	bh_a = (bmphandle_t)malloc(sizeof(*bh_a));
	memset(bh_a, 0, sizeof(struct bmphandle_s));	  

	//memcpy ( bh_a, (void*)bh, sizeof(struct bmphandle_s));
	bh_a->getpixel = bh->getpixel;
	//bh_a->height = bh->height;
	bh_a->bytes_per_line = bh->bytes_per_line;
	bh_a->palette =  bh->palette;
	
	
	bh_a->data= area_p ;

	int screen_x = 0;
	int screen_y = 0;
	
#if debug
	printf(" show area call 1 \n");
#endif
	switch(cmd)
	{
		case 1 : screen_x = 320 - x ;
			 screen_y = 240 - y ;
			 
			for(i = 0; i < screen_y ; i++)
			{
				for(j = 0; j < screen_x ; j++)
				{
					count++;
					//pixel = bmp_getpixel(bh_a, j, i);
					pixel = bmp_getpixel(bh, j, i);
					*(pfbmap+(i+y)*fbvar.xres + (j+x) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
				}
			}
			 break;

		case 2 : screen_x = x ;
			 screen_y = 240 -y ;
			
			for(i = 0; i < screen_y ; i++)
			{
				for(j = 0; j < screen_x ; j++)
				{
				count++;
				//pixel = bmp_getpixel(bh_a, j, i);
				pixel = bmp_getpixel(bh, j+(320-x), i);
				*(pfbmap+(i+y)*fbvar.xres + (j) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
				}
			}
			 break;

		case 3 : screen_x = 320 - x ;
			 screen_y = y ;
			 
			for(i = 0; i < screen_y ; i++)
			{
				for(j = 0; j < screen_x ; j++)
				{
				count++;
				//pixel = bmp_getpixel(bh_a, j, i);
				pixel = bmp_getpixel(bh, j, i+(240-y));
				*(pfbmap+(i)*fbvar.xres + (j+x) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
				}
			}
			 break;

		case 4 : screen_x = x ;
			 screen_y = y ;
			 
			for(i = 0; i < screen_y ; i++)
			{
				for(j = 0; j < screen_x ; j++)
				{
				count++;
				//pixel = bmp_getpixel(bh_a, j, i);
				pixel = bmp_getpixel(bh, j+(320-x), i+(240-y));
				*(pfbmap+(i)*fbvar.xres + (j) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
				}
			}
			 break;
	}//end switch
	

#if debug
	printf(" show area call 3\n");
	printf(" screen_x = %d , screen_y = %d \n",screen_x, screen_y);
#endif
/*
	for(i = 0; i < screen_y ; i++)
	{
		for(j = 0; j < screen_x ; j++)
		{
			count++;
			//pixel = bmp_getpixel(bh_a, j, i);
			pixel = bmp_getpixel(bh, j, i);
			*(pfbmap+(i+y)*fbvar.xres + (j+x) ) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
		}
	}
*/
//	printf("count is %d\n ",count);
}

