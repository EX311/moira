/*
 * bmplib.h : header for bmplib(simple bmp reading library)
 *
 * Copyright(C) 2002 holelee
 *
 */

//struct bmphandle_s;


typedef struct bmphandle_s *bmphandle_t;

struct bgrpixel
{
	unsigned char b, g, r;
};

struct bmphandle_s
{
	/* bmp header contents */
	int filesize;
	int reserved;
	int dataoffset;
	int headersize;
	int width;
	int height;
	short nplanes;
	short bpp;
	int compression;
	int bitmapsize;
	int hres;
	int vres;
	int ncolors;
	int importantcolors;

	/* palette, pixel data, getpixel function pointer */
	int npalette;
	int bytes_per_line;
	struct palette_s *palette;
	unsigned char *data;
	unsigned char *encodeddata;
	struct bgrpixel (*getpixel)(bmphandle_t, int, int);
	unsigned bsize_blue, bsize_green, bsize_red;
	unsigned boffset_blue, boffset_green, boffset_red;
};



bmphandle_t bmp_open(const char *filename);
void bmp_close(bmphandle_t bh);

int bmp_height(bmphandle_t bh);
int bmp_width(bmphandle_t bh);



struct bgrpixel bmp_getpixel(bmphandle_t bh, int x, int y);

