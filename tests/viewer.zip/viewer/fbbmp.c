/*
 * fbbmp.c : bmp drawing on frame buffer example
 *
 * Copyright(C) 2002 holelee
 *
 */

#include <stdio.h>
#include <stdlib.h> /* for exit */
#include <unistd.h> /* for open/close .. */
#include <fcntl.h>  /* for O_RDONLY */
#include <sys/ioctl.h> /* for ioctl */
#include <sys/mman.h> /* for mmap */
#include <linux/fb.h>  /* for fb_var_screeninfo, FBIOGET_VSCREENINFO */
#include "bmplib.h"

#define MIN(x, y) ((x) > (y) ? (y) : (x))

//#define FBDEVFILE "/dev/fb0"
//#define FBDEVFILE "/dev/oofb"
#define FBDEVFILE "/dev/fb/0"

typedef unsigned char ubyte;

static unsigned short makepixel(struct fb_var_screeninfo *pfbvar, ubyte r, ubyte g, ubyte b)
{
	unsigned short rnew, gnew, bnew;

	rnew = r >> (8-pfbvar->red.length);
	gnew = g >> (8-pfbvar->green.length);
	bnew = b >> (8-pfbvar->blue.length);

	return (unsigned short) ((rnew << pfbvar->red.offset)
			| (gnew << pfbvar->green.offset)
			| (bnew << pfbvar->blue.offset));
}

int main(int argc, char *argv[])
{
	int fbfd;
	unsigned short *pfbmap;
	struct fb_var_screeninfo fbvar;
	int i, j;
	struct bgrpixel pixel;
	bmphandle_t bh;

	if(argc != 2)
	{
		fprintf(stderr, "Usage:%s bmpfile\n", argv[0]);
		exit(1);
	}

	bh = bmp_open(argv[1]);
	if(bh == NULL)
	{
		fprintf(stderr, "Cannot open bmp file(%s)\n", argv[1]);
		fprintf(stderr, "File may be not bmp. Or file may be not supported by this program\n");
		exit(0);
	}

	fbfd = open(FBDEVFILE, O_RDWR);
	if(fbfd < 0)
	{
		perror("fbdev open");
		exit(1);
	}

	if(ioctl(fbfd, FBIOGET_VSCREENINFO, &fbvar) < 0)
	{
		perror("fbdev ioctl");
		exit(1);
	}

	if(fbvar.bits_per_pixel != 16)
	{
		fprintf(stderr, "bpp is not 16\n");
		exit(1);
	}

	pfbmap = (unsigned short *)
		mmap(0, fbvar.xres*fbvar.yres*16/8,
			PROT_READ|PROT_WRITE, MAP_SHARED, fbfd, 0);

	if((unsigned)pfbmap == (unsigned)-1)
	{
		perror("fbdev mmap");
		exit(1);
	}

	/* main loop */
	for(i = 0; i < MIN(bmp_height(bh), fbvar.yres); i++)
	{
		for(j = 0; j < MIN(bmp_width(bh), fbvar.xres); j++)
		{
			pixel = bmp_getpixel(bh, j, i);
			*(pfbmap+i*fbvar.xres+j) = makepixel(&fbvar, pixel.r, pixel.g, pixel.b);
		}
	}

	/* clean up */
	bmp_close(bh);
	munmap(pfbmap, fbvar.xres*fbvar.yres*16/8);
	close(fbfd);
	exit(0);
	return 0;
}

