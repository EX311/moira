cat /proc/board_status/IsConnect
cat /proc/board_status/IpInfo/IpInfo0
cat /proc/board_status/IpInfo/IpInfo1
cat /proc/board_status/IpInfo/IpInfo2
cat /proc/board_status/IpInfo/IpInfo3
cat /proc/board_status/AfterMasterIp/AfterMasterIp0
cat /proc/board_status/AfterMasterIp/AfterMasterIp1
cat /proc/board_status/AfterMasterIp/AfterMasterIp2
cat /proc/board_status/AfterMasterIp/AfterMasterIp3
cat /proc/board_status/MyLocation
cat /proc/board_status/MasterLocation
cat /proc/board_status/DeviceAttached

