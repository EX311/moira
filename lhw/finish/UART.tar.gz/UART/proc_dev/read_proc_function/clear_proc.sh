echo "" > /proc/board_status/IsConnect
echo "" > /proc/board_status/IpInfo/IpInfo0
echo "" > /proc/board_status/IpInfo/IpInfo1
echo "" > /proc/board_status/IpInfo/IpInfo2
echo "" > /proc/board_status/IpInfo/IpInfo3
echo "" > /proc/board_status/AfterMasterIp/AfterMasterIp0
echo "" > /proc/board_status/AfterMasterIp/AfterMasterIp1
echo "" > /proc/board_status/AfterMasterIp/AfterMasterIp2
echo "" > /proc/board_status/AfterMasterIp/AfterMasterIp3
echo "" > /proc/board_status/MyLocation
echo "" > /proc/board_status/MasterLocation
echo "" > /proc/board_status/DeviceAttached
 
